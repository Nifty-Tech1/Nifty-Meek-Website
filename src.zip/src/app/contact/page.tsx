export default function ContactPage() {
  return (
    <main className=" pt-24 min-h-screen flex flex-col justify-center items-center text-center px-6 text-white">
      <h1 className="text-5xl font-bold mb-6">Let’s Build Something Real</h1>

      <p className="text-gray-400 max-w-xl mb-10">
        If you're serious about building systems, scaling ideas, or working
        together — reach out.
      </p>

      <a
        href="mailto:bufukemukangasa@gmail.com"
        className="px-8 py-4 bg-white text-black rounded-2xl hover:scale-105 transition"
      >
        Contact Me
      </a>
    </main>
  );
}
