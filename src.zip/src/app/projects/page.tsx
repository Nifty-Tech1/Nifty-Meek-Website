import { getServerSupabase } from "../../lib/auth";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const supabase = await getServerSupabase();

  const { data: projects } = await supabase.from("projects").select("*");

  return (
    <main className="pt-24 px-10 py-24 max-w-6xl mx-auto text-white">
      <h1 className="text-4xl font-bold mb-12">Live Systems</h1>

      <div className="grid md:grid-cols-3 gap-8">
        {projects?.map((p) => (
          <div
            key={p.id}
            className="p-6 rounded-2xl border border-white/10 bg-white/5 backdrop-blur hover:scale-[1.02] transition"
          >
            <h2 className="text-xl font-semibold">{p.name}</h2>
            <p className="text-gray-400 mt-2">{p.description}</p>

            <span className="text-sm mt-4 inline-block text-green-400">
              ● {p.status}
            </span>
          </div>
        ))}
      </div>
    </main>
  );
}
