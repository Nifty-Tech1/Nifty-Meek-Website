"use client";
import { useState } from "react";
import { supabase } from "../../../../lib/supabase";
import { toast } from "sonner";

export default function NewLog() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tag, setTag] = useState("update");
  const [loading, setLoading] = useState(false);

  const createLog = async () => {
    setLoading(true);

    const { error } = await supabase
      .from("logs")
      .insert([{ title, content, tag }]);

    setLoading(false);

    if (error) {
      toast.error("Failed");
    } else {
      toast.success("Created 🚀");
    }
  };
  return (
    <div className="relative h-screen flex flex-col justify-center items-center text-center px-6 overflow-hidden">
      <div className="p-10 max-w-lg">
        <h1 className="text-2xl mb-6">New Log</h1>

        <input
          className="w-full p-3 mb-4 text-white bg-slate-800 rounded-2xl"
          placeholder="Title"
          onChange={(e) => setTitle(e.target.value)}
        />

        <textarea
          className="w-full p-3 text-white bg-slate-800 rounded-2xl"
          placeholder="What happened today?"
          onChange={(e) => setContent(e.target.value)}
        />

        <select
          className="px-8 py-4 m-4 bg-white text-black rounded-2xl hover:scale-105 transition cursor-pointer"
          onChange={(e) => setTag(e.target.value)}
        >
          <option value="update">Update</option>
          <option value="experiment">Experiment</option>
          <option value="win">Win</option>
          <option value="failure">Failure</option>
        </select>

        <button
          disabled={loading}
          onClick={createLog}
          className="px-8 py-4 m-4 bg-white text-black rounded-2xl hover:scale-105 transition cursor-pointer"
        >
          {loading ? "Creating..." : "Create"}
        </button>
      </div>
    </div>
  );
}
