import { getServerSupabase } from "../../lib/auth";
import { redirect } from "next/navigation";
import AdminProjectItem from "../components/AdminProjectItem";
import Link from "next/link";

export default async function AdminPage() {
  const supabase = await getServerSupabase();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: projects } = await supabase.from("projects").select("*");

  return (
    <div className="p-10">
      <h1 className="text-3xl mb-6">Admin Dashboard</h1>

      <a href="/admin/new" className="px-4 py-2 bg-white text-black rounded">
        + New Project
      </a>

      <Link
        href="/admin/logs/new"
        className="inline-block mt-6 px-6 py-3 bg-white text-black rounded-xl"
      >
        + New Log
      </Link>

      <div className="mt-8 space-y-4">
        {projects?.map((p) => (
          <AdminProjectItem key={p.id} project={p} />
        ))}
      </div>
    </div>
  );
}
