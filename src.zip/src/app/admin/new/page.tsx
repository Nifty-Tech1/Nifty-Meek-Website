"use client";
import { useState } from "react";
import { supabase } from "../../../lib/supabase";
import { toast } from "sonner";

export default function NewProject() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("Building");
  const [loading, setLoading] = useState(false);

  const createProject = async () => {
    await supabase.from("projects").insert([{ name, description, status }]);
    alert("Project created");
    toast.success("Project created successfully!🚀");
  };

  return (
    <div className="pt-24 relative h-screen flex flex-col justify-center items-center text-center px-6 overflow-hidden">
      <div className="p-10 max-w-lg">
        <h1 className="text-2xl mb-6">New Project</h1>

        <input
          className="w-full p-3 mb-4 text-white bg-slate-800 rounded-2xl"
          placeholder="Name"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          className="w-full p-3 mb-4 text-white bg-slate-800 rounded-2xl"
          placeholder="Description"
          onChange={(e) => setDescription(e.target.value)}
        />

        <select
          className="w-full p-3 py-4 mb-4 text-white bg-slate-800 rounded-2xl"
          onChange={(e) => setStatus(e.target.value)}
        >
          <option>Building</option>
          <option>Live</option>
          <option>Experiment</option>
        </select>

        <button
          disabled={loading}
          onClick={createProject}
          className="px-8 py-4 mt-4 bg-white text-black rounded-2xl hover:scale-105 hover:shadow-xl transition cursor-pointer"
        >
          {loading ? "Creating..." : "Create"}
        </button>
      </div>
    </div>
  );
}
