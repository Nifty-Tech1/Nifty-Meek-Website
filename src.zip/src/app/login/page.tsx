"use client";

import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast.error("Login failed");
    } else {
      toast.success("Welcome back 🚀");

      router.push("/admin");
      router.refresh(); // IMPORTANT
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center text-white">
      <div className="p-8 bg-white/5 border border-white/10 rounded-2xl">
        <h1 className="text-2xl mb-6">Admin Login</h1>

        <input
          className="w-full p-3 mb-4 text-black"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          className="w-full p-3 mb-4 text-black"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={handleLogin}
          className="w-full px-6 py-3 bg-white text-black rounded-xl"
        >
          Login
        </button>
      </div>
    </div>
  );
}
