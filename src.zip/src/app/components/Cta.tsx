import React from "react";

const Cta = () => {
  return (
    <div>
      <section className="text-center py-20">
        <h2 className="text-3xl font-bold mb-6">Follow the Journey</h2>

        <p className="text-gray-400 mb-6">
          I’m building real systems in public. Watch it unfold.
        </p>

        <button className="px-8 py-4 bg-white text-black rounded-2xl hover:scale-105 hover:shadow-xl transition cursor-pointer">
          Follow Journey Stay Updated
        </button>
      </section>
    </div>
  );
};

export default Cta;
