"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Navbar() {
  const path = usePathname();

  const linkClass = (href: string) =>
    `transition ${
      path === href ? "text-white" : "text-gray-400 hover:text-white"
    }`;

  return (
    <nav className="fixed top-0 w-full flex justify-between items-center px-8 py-5 bg-black/40 backdrop-blur-xl border-b border-white/10 z-50">
      <h1 className="font-semibold text-lg">Nifty Meek</h1>

      <div className="flex gap-8 text-sm items-center">
        <Link href="/" className={linkClass("/")}>
          Home
        </Link>
        <Link href="/projects" className={linkClass("/projects")}>
          Projects
        </Link>
        <Link href="/blog" className={linkClass("/blog")}>
          Insights
        </Link>
        <Link href="/contact" className={linkClass("/contact")}>
          Contact
        </Link>

        {/* Admin access */}
        {/*   <Link
          href="/login"
          className="text-xs px-3 py-1 border border-white/10 rounded-lg hover:bg-white/10 transition"
        >
          Admin
        </Link> */}
      </div>
    </nav>
  );
}
