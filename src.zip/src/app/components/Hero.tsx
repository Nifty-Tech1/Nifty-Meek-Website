"use client";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Link from "next/link";

export default function Hero() {
  const router = useRouter();

  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center text-center px-6 pt-28 pb-10 overflow-hidden">
      {/* Background Glow */}
      <div className="absolute w-150 h-150 bg-purple-500/20 blur-[120px] rounded-full -top-25" />

      <motion.h1
        initial={false}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-5xl md:text-7xl font-bold leading-tight max-w-4xl"
      >
        I Build Real Systems in Public. Not Ideas. Execution.
        <br />
        <span className="text-white/70">From Zambia → Scaling Globally.</span>
        <br />
      </motion.h1>

      <motion.p
        initial={false}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6 text-gray-400 max-w-xl"
      >
        Founder. Builder. Operator. Documenting execution, not theory.
      </motion.p>

      <br />

      <motion.div
        initial={false}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-10 flex gap-4"
      >
        <div className="mt-1 flex gap-4 flex-wrap justify-center">
          <Link href="/blog">
            <button className="px-8 py-4 bg-white text-black rounded-2xl hover:scale-105 hover:shadow-xl transition cursor-pointer">
              Follow Journey
            </button>
          </Link>

          <Link href="/projects">
            <button className="px-8 py-4 bg-white/20 text-white rounded-2xl hover:scale-105 hover:shadow-xl transition cursor-pointer">
              View Projects
            </button>
          </Link>
        </div>
      </motion.div>

      <section className="px-10 py-16 text-center">
        <h2 className="text-3xl font-bold mb-6">Proof of Work</h2>

        <div className="flex justify-center gap-10 text-gray-400">
          <div>
            <h3 className="text-2xl text-white">3+</h3>
            <p>Live Systems</p>
          </div>

          <div>
            <h3 className="text-2xl text-white">30+</h3>
            <p>Experiments</p>
          </div>

          <div>
            <h3 className="text-2xl text-white">Real-Time</h3>
            <p>Build Logs</p>
          </div>
        </div>
      </section>
    </section>
  );
}
