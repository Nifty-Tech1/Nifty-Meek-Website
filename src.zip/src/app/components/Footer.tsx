export default function Footer() {
  return (
    <footer className="border-t border-white/10 mt-20">
      <div className="max-w-6xl mx-auto px-10 py-10 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
        <p>© {new Date().getFullYear()} Nifty Meek. All rights reserved.</p>

        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="/projects" className="hover:text-white">
            Projects
          </a>
          <a href="/blog" className="hover:text-white">
            Logs
          </a>
          <a href="/contact" className="hover:text-white">
            Contact
          </a>
        </div>
      </div>
    </footer>
  );
}
