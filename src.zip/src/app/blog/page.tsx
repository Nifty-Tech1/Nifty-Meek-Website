import LogsPreview from "../../app/components/LogsPreview";

export default function BlogPage() {
  return (
    <main className="pt-24 text-white">
      <div className="pt-24">
        <h1 className="text-4xl font-bold text-center mb-10">
          Execution Timeline
        </h1>

        <LogsPreview />
      </div>
    </main>
  );
}
